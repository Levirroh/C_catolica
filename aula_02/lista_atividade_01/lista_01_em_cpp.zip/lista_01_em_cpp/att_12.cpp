#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float tempC, tempF;
	
	printf("Digite uma temperatura em Celsius \n");
	scanf("%f", &tempC);

	tempF = tempC * (9.0/5.0) + 32.0;

	printf("%f Celsius em Fahrenheit e: %f", tempC, tempF);
	
	return 0;
}