#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	int m,b,l, soma;
	
	printf("Escreva uma quantidade de macas, bananas e laranjas separando os valores com espaco \n");
	scanf("%i %i %i", &m, &b, &l);

	soma = m+b+l;


	printf("O total de frutas e: %i", soma);
	
	return 0;
}