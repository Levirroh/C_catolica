#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float m, cm;
	
	printf("Digite uma distancia em metros \n");
	scanf("%f", &m);

	cm = m*100/5;


	printf("um quinto %.2f m em centimetros e: %.2f", m,cm);
	
	return 0;
}