#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float altura;
	
	printf("Escreva uma altura em metros \n");
	scanf("%f", &altura);
	printf("Voce escreveu a altura: %.2f", altura);
	
	return 0;
}