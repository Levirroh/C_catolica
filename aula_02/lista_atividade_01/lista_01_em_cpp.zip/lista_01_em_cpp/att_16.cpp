#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float tempC, tempK;
	
	printf("Digite uma temperatura em Kelvin \n");
	scanf("%f", &tempK);

	tempC = tempK + 273.15;

	printf("%.2f Kelvin em Celsius e: %f", tempK, tempC);
	
	return 0;
}