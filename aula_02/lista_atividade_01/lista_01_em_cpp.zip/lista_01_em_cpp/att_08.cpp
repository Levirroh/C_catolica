#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float lado, area;
	
	printf("Digite o lado de um quadrado \n");
	scanf("%f", &lado);

	area = lado*lado;


	printf("A area total e: %.2f", area);
	
	return 0;
}