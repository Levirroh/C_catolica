#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float tempC, tempF;
	
	printf("Digite uma temperatura em Fahrenheit \n");
	scanf("%f", &tempF);

	tempC = 5 * (tempF-32.0)/9;

	printf("%f Fahrenheit em Celsius e: %f", tempF, tempC);
	
	return 0;
}