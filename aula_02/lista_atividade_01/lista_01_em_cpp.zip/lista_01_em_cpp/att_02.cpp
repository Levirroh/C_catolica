#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	int ano;
	
	printf("Escreva um ano de nascimento \n");
	scanf("%i", &ano);
	printf("Voce escreveu o ano %i", ano);
	
	return 0;
}