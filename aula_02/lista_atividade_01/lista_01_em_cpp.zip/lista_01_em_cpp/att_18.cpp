#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float tempC, tempK;
	
	printf("Digite uma temperatura em Celsius \n");
	scanf("%f", &tempC);

	tempK = tempC - 273.15;

	printf("%.2f Celsius em Kelvin e: %.2f", tempC, tempK);
	
	return 0;
}