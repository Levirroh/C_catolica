#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(){
	
	float km, ms;
	
	printf("Digite uma velocidade de um ciclista \n");
	scanf("%f", &km);

	ms = km/3.6;

	printf("%f Km/h e %f em M/s.", km, ms);
	
	return 0;
}