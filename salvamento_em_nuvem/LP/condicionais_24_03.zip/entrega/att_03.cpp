#include <stdio.h>
#include <stdlib.h>


int main(){
	
	//variaveis
	int n;
	
	printf("Digite um numero para descobrir se e par ou impar: \n");
	scanf("%i", &n);
	fflush(stdin);
	
	//processamento e saida
	
	if((n % 2) == 0) {
		printf("O numero e par");
	} else{
		printf("O numero e impar");
	}
	
	
	return 0;
}