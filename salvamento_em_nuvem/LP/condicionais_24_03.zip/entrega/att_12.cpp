#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	int dia;
	
	printf("Digite o dia de hoje : \n [1] - Domingo \n [2] - Segunda-Feira \n [3] - Terca-Feira \n [4] - Quarta-Feira \n [5] - Quinta-Feira \n [6] - Sexta-Feita \n [7] - Sabado \n");
	scanf("%i", &dia);
	fflush(stdin);

	//processamento e saida
		
	switch (dia){
		case 1 :
			printf("Hoje e Domingo!"); 
			break;
		case 2 : 
			printf("Hoje e Segunda!");
				break;
		case 3 :
			printf("Hoje e Terca!"); 
			break;	
		case 4 : 
			printf("Hoje e Quarta!"); 
			break;
		case 5 :
			printf("Hoje e Quinta!"); 
			break;
		case 6 : 
			printf("Hoje e Sexta!");
			break;
		case 7 : 
			printf("Hoje e Sabado!");
			break;
		default :
			printf("Vcoe digitou um valor invalido, tchau!"); 
	}
	
	
	
	return 0;
}