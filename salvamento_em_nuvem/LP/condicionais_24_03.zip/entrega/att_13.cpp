#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	int a , b , c , d;
	float media;
	printf("Digite a idade de todos do grupo (4 pessoas), separados por espaco! \n");
	scanf("%i %i %i %i", &a, &b, &c, &d);
	fflush(stdin);

	media = (a + b + c + d)/4;


	//processamento e saida
		
	if (media > 40){
		printf("Turma idosa");
	} else if (media >= 25 && media <= 40){
		printf("Turma adulta");
	} else {
		printf("Turma jovem");
	}
		
	
	
	
	return 0;
}