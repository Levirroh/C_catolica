#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	float n;
	
	printf("Digite um numero para descobrir se e inteiro ou nao: \n");
	scanf("%f", &n);
	fflush(stdin);

	//processamento e saida
		
	if(n == (int) n) {
		printf("O numero e inteiro \n");
	} else{
		printf("O numero nao e inteiro \n");
	}
	
	
	return 0;
}