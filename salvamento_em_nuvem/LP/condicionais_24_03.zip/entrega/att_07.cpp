#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	char s;
	
	printf("Digite uma unica letra para descobrir se e consoante ou vogal! \n");
	scanf("%c", &s);
	fflush(stdin);

	//processamento e saida
		
	switch (s){
		case 'A' : 
		case 'a' : 
		case 'E'  : 
		case 'e' : 
		case 'I'  : 
		case 'i' : 
		case 'O'  : 
		case 'o' : 
		case 'U'  : 
		case 'u' : 
			printf("Voce escolheu uma vogal \n");
			break;
		default:
			printf("Voce escolheu uma consoante!");
	}
	
	
	
	return 0;
}