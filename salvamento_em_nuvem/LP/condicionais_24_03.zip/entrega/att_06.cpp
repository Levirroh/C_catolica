#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	char s;
	
	printf("Escolha um : (F) feminino ou (M) masculino, digite uma letra : \n");
	scanf("%c", &s);
	fflush(stdin);

	//processamento e saida
		
	switch (s){
		case 'F' : 
			printf("Voce escolheu feminino \n");
			break;
		case 'M':
			printf("Voce escolheu masculino \n");
			break;
		default:
			printf("Voce nao escolheu uma opcao valida!.");
	}
	
	
	
	return 0;
}