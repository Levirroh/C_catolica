#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	int x , y , z;
	
	printf("Digite tres numeros inteiros separados por espaco! \n");
	scanf("%i %i %i", &x, &y, &z);
	fflush(stdin);


	//processamento e saida
		
	if (x > y && y > z){
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", z , y , x);
	} else if(y > x && x > z){
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", z , x , y);
	} else if(y > z && z > x){
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", x , z , y);
	} else if(z > y && y > x){
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", x , y , z);
	} else if(z > x && x > y){
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", y , x , z);
	} else{
		printf("Os numeros em ordem crescente sao: \n %i -> %i -> %i", y , z , x);
	}
	
	
	
	return 0;
}