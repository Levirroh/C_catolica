#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	int opcao;
	bool sair;
	float num, ndois, result;
	while (!sair){
		printf(" [ 1 ] - Adicao \n [ 2 ] - Subtracao \n [ 3 ] - Multiplicacao \n [ 4 ] - Divisao \n [ 5 ] - Fim \n");
		scanf("%i", &opcao);
		fflush(stdin);
	

		//processamento e saida
		switch (opcao){
			case 1:
				printf("Digite os dois numeros separados por um espaco: \n");
				scanf("%f %f", &num, &ndois);
				fflush(stdin);
				
				result = num + ndois;
				break;
			case 2:
				printf("Digite os dois numeros separados por um espaco: \n");
				scanf("%f %f", &num, &ndois);
				fflush(stdin);
				
				result = num - ndois;
				break;
			case 3:
				printf("Digite os dois numeros separados por um espaco: \n");
				scanf("%f %f", &num, &ndois);
				fflush(stdin);
				
				result = num * ndois;
				break;
			case 4:
				printf("Digite os dois numeros separados por um espaco: \n");
				scanf("%f %f", &num, &ndois);
				fflush(stdin);
				
				if (ndois == 0){
					printf("Impossivel divisao por zero! Digite outros valores! \n");
					break;
				}
				
				result = num / ndois;
				break;
			case 5:
				sair = true;
				break;
			default:
				printf("Numero invalido digitado!");	
		}
		if (!sair){	
			printf("O resultado da operacao escolhida foi : %.2f \n", result);
		} else {
			printf("Ate a proxima.");
		}
	}
		
	
	
	return 0;
}