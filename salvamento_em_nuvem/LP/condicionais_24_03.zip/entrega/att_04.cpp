#include <stdio.h>
#include <stdlib.h>


int main(){
	
	//variaveis
	int n;
	
	printf("Digite um numero para descobrir se e par ou impar: \n");
	scanf("%i", &n);
	fflush(stdin);
	
	//processamento e saida
	
	if((n % 2) == 0) {
		printf("O numero e par \n");
		printf("transformando-o em impar (somando 1) \n");
		n = n + 1;
		printf("agora ele e impar : %i", n);
	} else{
		printf("O numero e impar \n");
		printf("transformando-o em par (somando 1) \n");
		n = n + 1;
		printf("agora ele e par : %i", n);
	}
	
	
	return 0;
}