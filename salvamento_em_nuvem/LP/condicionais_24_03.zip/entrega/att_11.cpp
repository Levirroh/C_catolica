#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	char s;
	
	printf("Digite o seu turno (V) Vespertino, (M) Matutino ou (N) Noturno \n");
	scanf("%c", &s);
	fflush(stdin);

	//processamento e saida
		
	switch (s){
		case 'V' : 
		case 'v' :
			printf("Boa tarde \n");
			break;
		case 'M' : 
		case 'm' : 
			printf("Bom dia \n");
			break;
		case 'N' : 
		case 'n' : 
			printf("Boa noite \n");
			break;
		default:
			printf("Voce escolheu uma opcao incorreta!");
	}
	
	
	
	return 0;
}