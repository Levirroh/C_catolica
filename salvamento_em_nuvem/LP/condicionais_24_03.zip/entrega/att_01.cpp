#include <stdio.h>
#include <stdlib.h>


int main(){
	
	//variaveis
	int num, ndois;
	
	printf("Digite dois numeros inteiros separados por um espaco: \n");
	scanf("%i %i", &num, &ndois);
	fflush(stdin);
	
	//processamento e saida
	
	if(num == ndois) {
		printf("Os numeros sao iguais");
	} else if (num>ndois) {
		printf("O numero %i e maior que o numero %i", num, ndois);
	} else{
		printf("O numero %i e maior que o numero %i", ndois, num);
	}
	
	
	return 0;
}