#include <stdio.h>
#include <stdlib.h>


int main(){
	
	//variaveis
	int n;
	
	printf("Digite um numero positivo ou negativo para o programa identificar o sinal: \n");
	scanf("%i", &n);
	fflush(stdin);
	
	//processamento e saida
	
	if(n < 0) {
		printf("O numero e negativo");
	} else if (n == 0){
		printf("O numero e igual a zero e nao possui sinais", n);
	} else {
		printf("O numero e positivo");
	}
	
	
	return 0;
}