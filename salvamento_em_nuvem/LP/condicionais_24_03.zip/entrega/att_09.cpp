#include <stdio.h>
#include <stdlib.h>

int main(){
	
	//variaveis
	int x , y , z;
	float media;
	printf("Digite suas tres notas para saber se passou ou nao! \n");
	scanf("%i %i %i", &x, &y, &z);
	fflush(stdin);

	media = (x + y + z)/3;


	//processamento e saida
		
	if (media == 10){
		printf("Voce PASSOU COM DISTINCAO!!!!");
	} else if (media >= 7){
		printf("Voce PASSOU!!!");
	} else {
		printf("Voce reprovou...");
	}
		
	
	
	
	return 0;
}